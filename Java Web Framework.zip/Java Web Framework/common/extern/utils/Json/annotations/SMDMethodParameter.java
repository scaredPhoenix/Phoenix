package common.extern.utils.Json.annotations;

import java.lang.annotation.Annotation;

public interface SMDMethodParameter extends Annotation
{
    public abstract String name();
}