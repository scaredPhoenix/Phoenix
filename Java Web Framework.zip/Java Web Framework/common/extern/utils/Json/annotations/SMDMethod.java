package common.extern.utils.Json.annotations;


import java.lang.annotation.Annotation;

public interface SMDMethod extends Annotation
{
    public abstract String name();
}