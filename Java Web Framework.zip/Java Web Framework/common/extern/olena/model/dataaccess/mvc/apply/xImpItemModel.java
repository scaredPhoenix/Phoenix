package common.extern.olena.model.dataaccess.mvc.apply;

import common.extern.olena.model.dataaccess.mvc.base.item_Model;
import common.extern.olena.model.dataaccess.mvc.base.tbl_Model;
/**
* @author scaredPhoenix 
* @version  2013-03-25 10:14:12
*/
public class xImpItemModel extends item_Model{
	public static int fldNo = -1;
	public xImpItemModel(tbl_Model tblInfo) {
		super();
		super.init(tblInfo);
	}
}
