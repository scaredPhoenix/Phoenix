package common.extern.olena.model.dataaccess.util.core.query.components.mssql;

import common.extern.olena.model.dataaccess.mvc.base.IItem_Model;

public class msmdbSqlQuery extends mssqlSqlQuery{

	public msmdbSqlQuery(IItem_Model tableInfos) {
		super(tableInfos);
	}

}
