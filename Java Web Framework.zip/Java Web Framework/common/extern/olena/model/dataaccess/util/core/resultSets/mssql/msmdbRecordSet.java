package common.extern.olena.model.dataaccess.util.core.resultSets.mssql;

import common.extern.olena.model.dataaccess.mvc.base.IItem_Model;

public class msmdbRecordSet extends mssqlRecordSet{

	public msmdbRecordSet(IItem_Model itemInfos) {
		super(itemInfos);
	}
}
