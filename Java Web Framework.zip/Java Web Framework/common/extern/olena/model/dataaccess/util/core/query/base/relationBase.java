package common.extern.olena.model.dataaccess.util.core.query.base;

import common.extern.olena.model.dataaccess.util.core.query.sqlQuery_Model;

/**
 *
 * @author scaredPhoenix
 * @version ModelWeb 1.0, 2012. 01. 14 AM 11:42:00
 * @since ModelWeb 1.0
 */
public class relationBase 
{
	public String toSQLString(sqlQuery_Model queryModel, int nSeek)
	{
		return null;
	}
}
